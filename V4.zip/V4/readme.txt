#### Etape suivante de "Version 1: PHP & SQLite"
Un fichier docker-compose.yml est configuré afin de pouvoir lancer trois container à la fois. Il contient la configuration du site web, ainsi que d'une base de donnée Postgrès et MariaDB. 

Pour lancer les instances suivantes, il suffit de suivre ces étapes:

# cd V2
# docker compose build
# docker compose up

Le site est hébergé sur le port 8000, donc pour y accéder:
localhost:8080


#Création du dossier d'accueil du projet

 mkdir api
 cd api

#dans le dossier Projet, exécuter:

source api_env/bin/activate

uvicorn main:app --reload # pour le fichier générant le jeton
localhost:8000

uvicorn conso:app --reload --port 8001 # pour le fichier validant le jeton
localhost:8001

#un fichier appelapi.py est disponible dans Projet/api pour tester les jetons.
python3 appelapi.py

#Il est possible de tester la méthode CRUD sur localhost:8001, il faut rentrer le jeton: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAiLCJzdWIiOiJ2aXNpdGV1ciIsImF1ZCI6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMSIsImlhdCI6MTcwMjgzNTY1NiwiZXhwIjoxNzU2ODM1NjU2LCJub20iOiJ2aXNpdGV1ciIsInJvbGUiOiJ2aXNpdGV1ciJ9.sRaSYM5hSVxMd3whwaup8HSV1siEGSbZYt4QpjgxTeo
