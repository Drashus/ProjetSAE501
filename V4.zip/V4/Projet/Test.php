
<?php
    include 'formulaires.php';
    include 'fonctions.php';

$test = VerifAdmin("admin");
var_dump($test);
?>
