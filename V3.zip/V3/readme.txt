#### Etape suivante de "Version 1: PHP & SQLite"
Un fichier docker-compose.yml est configuré afin de pouvoir lancer trois container à la fois. Il contient la configuration du site web, ainsi que d'une base de donnée Postgrès et MariaDB. 

Pour lancer les instances suivantes, il suffit de suivre ces étapes:

# cd V2
# docker compose build
# docker compose up

Le site est hébergé sur le port 8000, donc pour y accéder:
localhost:8080


Création du dossier d'accueil du projet

root@debian10:/home/etudiant/# mkdir api
root@debian10:/home/etudiant/# cd api


dans le dossier Projet, exécuter:

source api_env/bin/activate

uvicorn main:app --reload

#login et pass: testuser / testpassword

