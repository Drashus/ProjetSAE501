import sqlite3

# Chemin vers le fichier de base de données SQLite
db_file_path = "Projet/Fleurs/fleurs.db"

# Connexion à la base de données
conn = sqlite3.connect(db_file_path)

# Création d'un objet curseur
cursor = conn.cursor()

# Exemple de requête : sélectionnez toutes les lignes de la table "exemple_table"
cursor.execute("SELECT * FROM produit")

# Récupération des résultats
rows = cursor.fetchall()

# Affichage des résultats
for row in rows:
    print(row)

# Fermeture du curseur et de la connexion
cursor.close()
conn.close()

